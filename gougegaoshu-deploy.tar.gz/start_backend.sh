#!/bin/bash
cd /Users/daniel/Documents/GitHub/gougegaoshu/backend
node server.js
