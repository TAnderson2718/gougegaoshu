#!/bin/bash
cd /Users/daniel/Documents/GitHub/gougegaoshu/frontend
npm start
